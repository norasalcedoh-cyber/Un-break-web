(async () => {
// Runs inside the extension's isolated content-script world on Instagram only.
let modoDemo = false;
try {
  const state = await chrome.runtime.sendMessage({ type: 'demo:get' });
  modoDemo = state?.ok === true && state.enabled === true;
} catch {
  // If the worker is unavailable, preserve normal behavior without claiming demo activation.
}

function showDemoControl(active) {
  const host = document.createElement('div');
  host.id = 'un-break-demo-control';
  host.style.cssText = 'position:fixed!important;bottom:20px!important;right:20px!important;z-index:2147483647!important;visibility:visible!important;';
  const root = host.attachShadow({ mode: 'closed' });
  const box = document.createElement('section');
  box.style.cssText = 'max-width:320px;padding:16px;background:#eeeeea;color:#111;border:1px solid #111;font:14px/1.45 Arial,sans-serif;box-shadow:0 4px 24px #0003;';
  const text = document.createElement('p');
  text.style.margin = '0 0 12px';
  text.setAttribute('role', 'status');
  text.textContent = active
    ? 'UN-BREAK · Demo activa en esta pestaña. Desliza rápido para comprimir; detente unos segundos para deformar. Tras 15 segundos de navegación activa empezarán a desaparecer imágenes.'
    : 'UN-BREAK · ¿Quieres activar la demostración en esta pestaña? Verás los efectos con tiempos más cortos. No se envían datos personales.';
  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = active ? 'Salir de la demo' : 'Activar demostración';
  button.style.cssText = 'padding:9px;background:#111;color:white;border:0;cursor:pointer;font:inherit;';
  button.addEventListener('click', async () => {
    button.disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: 'demo:set', enabled: !active });
      if (!result?.ok || result.enabled !== !active) throw new Error('Demo state not confirmed');
      // Reload restores all original DOM styles and restarts the normal/demo timers.
      location.reload();
    } catch {
      text.textContent = 'No se pudo cambiar el modo. Recarga la extensión en chrome://extensions y vuelve a intentarlo.';
      button.disabled = false;
    }
  });
  box.append(text, button);
  if (!active) {
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.textContent = 'Ahora no';
    cancel.style.cssText = 'margin-left:12px;padding:9px;cursor:pointer;font:inherit;';
    cancel.addEventListener('click', () => host.remove());
    box.append(cancel);
  }
  root.append(box);
  document.body.append(host);
}

function checkDemoRequest() {
  if (location.hash !== '#un-break-demo') return;
  // Consume the request so exiting and reloading never activates it again.
  history.replaceState(history.state, '', location.pathname + location.search);
  if (!document.getElementById('un-break-demo-control')) showDemoControl(modoDemo);
}
if (modoDemo) showDemoControl(true);
checkDemoRequest();
window.addEventListener('hashchange', checkDemoRequest);


console.log("CULACCINO — Iniciado");

// =====================================
// 1. CONFIGURACIÓN
// =====================================

// KERNING
const INICIO_KERNING = modoDemo ? 600 : 5 * 1000;
const DURACION_KERNING = modoDemo ? 1500 : 4 * 1000;
const KERNING_MINIMO = -3.6;
const KERNING_BASE = -0.15;
const UMBRAL_SCROLL_RAPIDO = modoDemo ? 2 : 3;
const INCREMENTO_SCROLL_RAPIDO = modoDemo ? 400 : 250;

// DESAPARICIÓN
const INICIO_DESAPARICION = modoDemo ? 15 * 1000 : 50 * 1000;
const INTERVALO_DESAPARICION = modoDemo ? 2000 : 2500;

// DEFORMACIÓN DE IMAGENES
const INICIO_SATURACION_IMAGEN = modoDemo ? 500 : 2 * 1000;
const DURACION_SATURACION_IMAGEN = modoDemo ? 1000 : 3 * 1000;
const INICIO_DEFORMACION_IMAGEN = modoDemo ? 1200 : 5 * 1000;
const DURACION_DEFORMACION_IMAGEN = modoDemo ? 2500 : 8 * 1000;
const INTERVALO_DEFORMACION_IMAGEN = 500;
const DURACION_RESTAURACION_IMAGEN = 1500;
const MAXIMO_DEFORMACION_IMAGEN = 150;
const MAXIMO_SATURACION_IMAGEN = 1.6;


// =====================================
// 2. TIEMPO DE NAVEGACIÓN
// =====================================

let tiempoActivo = 0;
let numeroScrolls = 0;

let instagramActivo = !document.hidden;
let inicioPeriodo = instagramActivo
  ? Date.now()
  : null;

function pausarTiempo() {
  if (!instagramActivo) return;

  tiempoActivo += Date.now() - inicioPeriodo;
  instagramActivo = false;
  inicioPeriodo = null;
}

function reanudarTiempo() {
  if (instagramActivo) return;

  instagramActivo = true;
  inicioPeriodo = Date.now();
}

document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    pausarTiempo();
  } else {
    reanudarTiempo();
  }
});

window.addEventListener("pagehide", pausarTiempo);

function obtenerTiempoActual() {
  if (!instagramActivo) {
    return tiempoActivo;
  }

  return tiempoActivo + (Date.now() - inicioPeriodo);
}


// =====================================
// 3. SCROLL
// =====================================

let tiempoScrollActivo = 0;
let ultimoMovimientoScroll = 0;
let rachaScroll = 0;
let scrollActivo = false;

window.addEventListener("scroll", () => {
  const ahora = Date.now();
  rachaScroll = ahora - ultimoMovimientoScroll <= 250
    ? rachaScroll + 1
    : 1;
  numeroScrolls++;
  ultimoMovimientoScroll = ahora;
  scrollActivo = true;
}, {
  passive: true,
  capture: true
});

function aplicarKerning() {
  if (!scrollActivo && tiempoScrollActivo < INICIO_KERNING) {
    return;
  }

  if (tiempoScrollActivo < INICIO_KERNING) {
    return;
  }

  const tiempoEfectivo = Math.min(
    tiempoScrollActivo - INICIO_KERNING,
    DURACION_KERNING
  );

  const progreso = Math.min(
    tiempoEfectivo / DURACION_KERNING,
    1
  );

  const kerning = Math.max(
    KERNING_MINIMO,
    KERNING_BASE - (progreso * (KERNING_BASE - KERNING_MINIMO + 0.7))
  );

  const textos = document.querySelectorAll(
    "article p, article span, article a, article li, article time, article h1, article h2, article h3"
  );

  textos.forEach((elemento) => {
    if (
      elemento.classList.contains(
        "culaccino-desaparecido"
      )
    ) {
      return;
    }

    elemento.style.setProperty(
      "letter-spacing",
      `${kerning}px`,
      "important"
    );
  });
}

setInterval(() => {
  const ahora = Date.now();

  if (scrollActivo && ahora - ultimoMovimientoScroll <= 250) {
    tiempoScrollActivo = Math.min(
      tiempoScrollActivo + (
        rachaScroll >= UMBRAL_SCROLL_RAPIDO
          ? INCREMENTO_SCROLL_RAPIDO
          : 100
      ),
      INICIO_KERNING + DURACION_KERNING
    );
    aplicarKerning();
    return;
  }

  rachaScroll = 0;

  if (tiempoScrollActivo >= INICIO_KERNING) {
    aplicarKerning();
  }

  scrollActivo = false;
}, 100);


// =====================================
// 4. DESAPARICIÓN ALEATORIA
// =====================================

const elementosDesaparecidos = new WeakSet();

function desaparecerElemento() {
  if (!instagramActivo) return;

  if (
    obtenerTiempoActual() <
    INICIO_DESAPARICION
  ) {
    return;
  }

  const candidatos = Array.from(
    document.querySelectorAll(
      "article img, article video"
    )
  ).filter((elemento) => {
    if (elementosDesaparecidos.has(elemento)) {
      return false;
    }

    const rect = elemento.getBoundingClientRect();

    return (
      rect.width > 50 &&
      rect.height > 12 &&
      rect.bottom > 0 &&
      rect.top < window.innerHeight
    );
  });

  if (candidatos.length === 0) {
    return;
  }

  const indice = Math.floor(
    Math.random() * candidatos.length
  );

  const elegido = candidatos[indice];

  elegido.classList.add(
    "culaccino-desaparecido"
  );

  elementosDesaparecidos.add(elegido);

  console.log("CULACCINO: elemento eliminado");
}

setInterval(
  desaparecerElemento,
  INTERVALO_DESAPARICION
);

const estadosImagenes = new WeakMap();

function deformarImagenesQuietas() {
  if (!instagramActivo) return;

  filtrosDeformacion.forEach((filtro, imagen) => {
    if (!imagen.isConnected) {
      const estado = estadosImagenes.get(imagen);
      if (estado && estado.animacionRecuperacion !== null) {
        cancelAnimationFrame(estado.animacionRecuperacion);
      }
      restaurarFiltroContenedor(filtro);
      filtro.elemento.remove();
      filtrosDeformacion.delete(imagen);
    }
  });

  const imagenes = Array.from(
    document.querySelectorAll(
      "article img, article video"
    )
  );

  imagenes.forEach((imagen) => {
    const rect = imagen.getBoundingClientRect();
    const ahora = Date.now();
    const visible = (
      rect.width > 50 &&
      rect.height > 12 &&
      rect.bottom > 0 &&
      rect.top < window.innerHeight
    );

    let estado = estadosImagenes.get(imagen);
    if (!estado) {
      if (!visible) return;

      estado = {
        izquierda: rect.left,
        arriba: rect.top,
        ancho: rect.width,
        alto: rect.height,
        ultimoMovimiento: ahora,
        nivel: 0,
        saturacion: 1,
        animacionRecuperacion: null
      };
      estadosImagenes.set(imagen, estado);
    }

    const seMovio = (
      Math.abs(rect.left - estado.izquierda) > 1 ||
      Math.abs(rect.top - estado.arriba) > 1 ||
      Math.abs(rect.width - estado.ancho) > 1 ||
      Math.abs(rect.height - estado.alto) > 1
    );
    estado.izquierda = rect.left;
    estado.arriba = rect.top;
    estado.ancho = rect.width;
    estado.alto = rect.height;

    if (seMovio) {
      estado.ultimoMovimiento = ahora;
      const filtro = filtrosDeformacion.get(imagen);
      if (filtro && estado.nivel > 0) {
        restaurarDeformacionGradualmente(filtro, estado);
      }
    }

    if (!visible) return;

    const tiempoQuieto = ahora - estado.ultimoMovimiento;
    if (tiempoQuieto >= INICIO_SATURACION_IMAGEN) {
      const progresoSaturacion = Math.min(
        (tiempoQuieto - INICIO_SATURACION_IMAGEN) /
          DURACION_SATURACION_IMAGEN,
        1
      );
      estado.saturacion = Math.max(
        estado.saturacion,
        1 + progresoSaturacion * (MAXIMO_SATURACION_IMAGEN - 1)
      );
    }

    if (estado.saturacion > 1) {
      imagen.style.setProperty(
        "filter",
        `saturate(${estado.saturacion})`,
        "important"
      );
    } else {
      imagen.style.removeProperty("filter");
    }

    if (tiempoQuieto >= INICIO_DEFORMACION_IMAGEN) {
      const progreso = Math.min(
        (tiempoQuieto - INICIO_DEFORMACION_IMAGEN) /
          DURACION_DEFORMACION_IMAGEN,
        1
      );
      if (estado.animacionRecuperacion !== null) {
        cancelAnimationFrame(estado.animacionRecuperacion);
        estado.animacionRecuperacion = null;
      }
      estado.nivel = progreso * MAXIMO_DEFORMACION_IMAGEN;
      const filtro = obtenerFiltroDeformacion(
        imagen,
        obtenerEspacioFiltros()
      );
      actualizarDeformacion(filtro, estado.nivel);
    }
  });
}

let espacioFiltros;
let siguienteIdFiltro = 0;
const filtrosDeformacion = new Map();

function actualizarDeformacion(filtro, nivel) {
  filtro.desplazamiento.setAttribute("scale", nivel.toString());

  if (nivel > 0) {
    actualizarLimitesFiltroDeformacion(filtro);
    filtro.contenedor.style.setProperty(
      "filter",
      `url("#${filtro.id}")`,
      "important"
    );
    filtro.contenedor.style.setProperty(
      "overflow",
      "visible",
      "important"
    );
  } else {
    restaurarFiltroContenedor(filtro);
  }
}

function restaurarDeformacionGradualmente(filtro, estado) {
  if (estado.animacionRecuperacion !== null) return;

  const nivelInicial = estado.nivel;
  const inicio = performance.now();

  function animarRestauracion(ahora) {
    const progreso = Math.min(
      (ahora - inicio) / DURACION_RESTAURACION_IMAGEN,
      1
    );
    estado.nivel = nivelInicial * (1 - progreso);
    actualizarDeformacion(filtro, estado.nivel);

    if (progreso < 1) {
      estado.animacionRecuperacion = requestAnimationFrame(
        animarRestauracion
      );
    } else {
      estado.animacionRecuperacion = null;
    }
  }

  estado.animacionRecuperacion = requestAnimationFrame(animarRestauracion);
}

function obtenerEspacioFiltros() {
  if (espacioFiltros) return espacioFiltros;

  const svg = document.createElementNS(
    "http://www.w3.org/2000/svg",
    "svg"
  );
  svg.setAttribute("aria-hidden", "true");
  svg.style.position = "absolute";
  svg.style.width = "0";
  svg.style.height = "0";
  svg.style.overflow = "hidden";

  espacioFiltros = document.createElementNS(
    "http://www.w3.org/2000/svg",
    "defs"
  );
  svg.appendChild(espacioFiltros);
  (document.body || document.documentElement).appendChild(svg);

  return espacioFiltros;
}

function obtenerFiltroDeformacion(imagen, defs) {
  const existente = filtrosDeformacion.get(imagen);
  if (existente) return existente;

  const contenedor = imagen.parentElement;
  if (!contenedor) {
    throw new Error("La imagen no tiene un contenedor para deformar");
  }

  const id = `culaccino-distortion-${Date.now()}-${siguienteIdFiltro++}`;
  const filtro = document.createElementNS(
    "http://www.w3.org/2000/svg",
    "filter"
  );
  filtro.setAttribute("id", id);
  filtro.setAttribute("filterUnits", "userSpaceOnUse");
  filtro.setAttribute("color-interpolation-filters", "sRGB");

  const ruido = document.createElementNS(
    "http://www.w3.org/2000/svg",
    "feTurbulence"
  );
  ruido.setAttribute("type", "fractalNoise");
  ruido.setAttribute("baseFrequency", "0.006 0.025");
  ruido.setAttribute("numOctaves", "2");
  ruido.setAttribute("seed", String(siguienteIdFiltro));
  ruido.setAttribute("result", "ondas");
  filtro.appendChild(ruido);

  const desplazamiento = document.createElementNS(
    "http://www.w3.org/2000/svg",
    "feDisplacementMap"
  );
  desplazamiento.setAttribute("in", "SourceGraphic");
  desplazamiento.setAttribute("in2", "ondas");
  desplazamiento.setAttribute("xChannelSelector", "R");
  desplazamiento.setAttribute("yChannelSelector", "G");
  desplazamiento.setAttribute("scale", "0");
  filtro.appendChild(desplazamiento);

  defs.appendChild(filtro);

  const resultado = {
    id,
    desplazamiento,
    elemento: filtro,
    contenedor,
    filtroOriginalContenedor: contenedor.style.getPropertyValue("filter"),
    prioridadFiltroOriginalContenedor: contenedor.style.getPropertyPriority(
      "filter"
    ),
    overflowOriginalContenedor: contenedor.style.getPropertyValue("overflow"),
    prioridadOverflowOriginalContenedor: contenedor.style.getPropertyPriority(
      "overflow"
    )
  };
  filtrosDeformacion.set(imagen, resultado);
  return resultado;
}

function actualizarLimitesFiltroDeformacion(filtro) {
  const rect = filtro.contenedor.getBoundingClientRect();
  const margen = MAXIMO_DEFORMACION_IMAGEN;

  filtro.elemento.setAttribute("x", String(-margen));
  filtro.elemento.setAttribute("y", String(-margen));
  filtro.elemento.setAttribute("width", String(rect.width + margen * 2));
  filtro.elemento.setAttribute("height", String(rect.height + margen * 2));
}

function restaurarFiltroContenedor(filtro) {
  const filtroAplicado = `url("#${filtro.id}")`;

  if (filtro.contenedor.style.getPropertyValue("filter") === filtroAplicado) {
    if (filtro.filtroOriginalContenedor) {
      filtro.contenedor.style.setProperty(
        "filter",
        filtro.filtroOriginalContenedor,
        filtro.prioridadFiltroOriginalContenedor
      );
    } else {
      filtro.contenedor.style.removeProperty("filter");
    }
  }

  if (filtro.contenedor.style.getPropertyValue("overflow") === "visible") {
    if (filtro.overflowOriginalContenedor) {
      filtro.contenedor.style.setProperty(
        "overflow",
        filtro.overflowOriginalContenedor,
        filtro.prioridadOverflowOriginalContenedor
      );
    } else {
      filtro.contenedor.style.removeProperty("overflow");
    }
  }
}

setInterval(
  deformarImagenesQuietas,
  INTERVALO_DEFORMACION_IMAGEN
);

// =====================================
// 6. TRANSFORMACIÓN ASCII DEL FEED
// =====================================

const MAXIMO_PUBLICACIONES_ANTES_ASCII = 7;
const publicacionesContadas = new WeakSet();
let publicacionesRecorridas = 0;
let modoAsciiActivado = false;
let observadorPublicaciones;
let observadorNuevasPublicaciones;

function contarPublicacionesVisibles(entradas) {
  entradas.forEach((entrada) => {
    if (
      modoAsciiActivado ||
      !entrada.isIntersecting ||
      publicacionesContadas.has(entrada.target)
    ) {
      return;
    }

    publicacionesContadas.add(entrada.target);
    publicacionesRecorridas++;

    if (publicacionesRecorridas > MAXIMO_PUBLICACIONES_ANTES_ASCII) {
      transformarInterfazEnAscii();
    }
  });
}

function observarPublicacion(elemento) {
  if (modoAsciiActivado) return;

  if (
    elemento.matches("article") &&
    !publicacionesContadas.has(elemento)
  ) {
    observadorPublicaciones.observe(elemento);
  }

  elemento.querySelectorAll("article").forEach((articulo) => {
    if (!publicacionesContadas.has(articulo)) {
      observadorPublicaciones.observe(articulo);
    }
  });
}

function iniciarConteoPublicaciones() {
  observadorPublicaciones = new IntersectionObserver(
    contarPublicacionesVisibles,
    { threshold: 0 }
  );

  document.querySelectorAll("article").forEach(observarPublicacion);

  observadorNuevasPublicaciones = new MutationObserver((cambios) => {
    cambios.forEach((cambio) => {
      cambio.addedNodes.forEach((nodo) => {
        if (nodo instanceof HTMLElement) {
          observarPublicacion(nodo);
        }
      });
    });
  });

  observadorNuevasPublicaciones.observe(document.body, {
    childList: true,
    subtree: true
  });
}

function transformarInterfazEnAscii() {
  if (modoAsciiActivado) return;
  modoAsciiActivado = true;

  observadorPublicaciones.disconnect();
  observadorNuevasPublicaciones.disconnect();

  const pantalla = document.createElement("canvas");
  pantalla.className = "culaccino-ascii";
  pantalla.setAttribute("aria-label", "Instagram transformado en arte ASCII");
  pantalla.setAttribute("role", "img");
  document.body.appendChild(pantalla);
  document.documentElement.classList.add("culaccino-ascii-mode");

  const contexto = pantalla.getContext("2d");
  if (!contexto) {
    pantalla.remove();
    document.documentElement.classList.remove("culaccino-ascii-mode");
    console.error("CULACCINO: no se pudo crear la pantalla ASCII");
    return;
  }

  const caracteres = "01{}[]<>/\\|_=+-*#%$@ABCDEF";
  const selectoresVisuales = [
    "img",
    "video",
    "svg",
    "canvas:not(.culaccino-ascii)",
    "button",
    "[role='button']",
    "p",
    "span",
    "a",
    "time",
    "h1",
    "h2",
    "h3"
  ].join(",");

  function tieneTextoDirecto(elemento) {
    return Array.from(elemento.childNodes).some(
      (nodo) => nodo.nodeType === Node.TEXT_NODE && nodo.textContent.trim()
    );
  }

  function dibujarRegionAscii(rectangulo, indiceInicial, ancho, alto) {
    const izquierda = Math.max(0, rectangulo.left);
    const arriba = Math.max(0, rectangulo.top);
    const derecha = Math.min(ancho, rectangulo.right);
    const abajo = Math.min(alto, rectangulo.bottom);

    if (derecha <= izquierda || abajo <= arriba) return;

    const celdaAncho = 6;
    const celdaAlto = 10;
    const columnas = Math.ceil((derecha - izquierda) / celdaAncho);
    const filas = Math.ceil((abajo - arriba) / celdaAlto);

    contexto.save();
    contexto.beginPath();
    contexto.rect(izquierda, arriba, derecha - izquierda, abajo - arriba);
    contexto.clip();
    contexto.font = "9px 'Courier New', monospace";
    contexto.textBaseline = "top";

    for (let fila = 0; fila < filas; fila++) {
      for (let columna = 0; columna < columnas; columna++) {
        const indice = (
          indiceInicial +
          fila * 17 +
          columna * 31 +
          fila * columna
        ) % caracteres.length;
        const tono = (fila + columna + indiceInicial) % 3;
        contexto.fillStyle = ["#ff4fa3", "#ff80bd", "#e8348d"][tono];
        contexto.fillText(
          caracteres[indice],
          izquierda + columna * celdaAncho,
          arriba + fila * celdaAlto
        );
      }
    }

    contexto.restore();
  }

  function dibujarPantallaAscii() {
    const ancho = window.innerWidth;
    const alto = window.innerHeight;
    const escala = Math.min(window.devicePixelRatio || 1, 2);

    pantalla.width = ancho * escala;
    pantalla.height = alto * escala;
    contexto.setTransform(escala, 0, 0, escala, 0, 0);
    contexto.clearRect(0, 0, ancho, alto);

    const regiones = Array.from(
      document.querySelectorAll(selectoresVisuales)
    ).filter((elemento) => {
      if (
        elemento.matches("p, span, a, time, h1, h2, h3") &&
        !tieneTextoDirecto(elemento)
      ) {
        return false;
      }
      const rectangulo = elemento.getBoundingClientRect();
      return (
        rectangulo.width > 2 &&
        rectangulo.height > 2 &&
        rectangulo.right > 0 &&
        rectangulo.bottom > 0 &&
        rectangulo.left < ancho &&
        rectangulo.top < alto
      );
    });

    regiones.forEach((elemento, indice) => {
      dibujarRegionAscii(
        elemento.getBoundingClientRect(),
        indice * 13,
        ancho,
        alto
      );
    });
  }

  window.addEventListener("resize", dibujarPantallaAscii);
  window.addEventListener("scroll", dibujarPantallaAscii, { passive: true });
  dibujarPantallaAscii();
  console.log("CULACCINO: interfaz transformada en ASCII");
}

if (!modoDemo) iniciarConteoPublicaciones();


// =====================================
// 7. CONSOLA DE PRUEBAS
// =====================================

setInterval(() => {
  console.log("CULACCINO");
  console.log(
    "Tiempo:",
    Math.floor(obtenerTiempoActual() / 1000),
    "segundos"
  );
  console.log("Scroll:", numeroScrolls);
}, 5000);

})();
